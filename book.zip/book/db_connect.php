<?php
$server = "localhost";
$db = "book";
$pwd = "";
$uname = "root";

$con = mysqli_connect($server, $uname, $pwd, $db);
?>